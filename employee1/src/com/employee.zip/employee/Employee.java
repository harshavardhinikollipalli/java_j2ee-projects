package com.employee;

public class Employee {

	private String employeeId;
	private String employeeName;
	private double employeeSlary;
	private int employeeLoan;
	private int employeeExp;
	private String employeeLoc;
	
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public double getEmployeeSlary() {
		return employeeSlary;
	}
	public void setEmployeeSlary(double employeeSlary) {
		this.employeeSlary = employeeSlary;
	}
	public int getEmployeeLoan() {
		return employeeLoan;
	}
	public void setEmployeeLoan(int employeeLoan) {
		this.employeeLoan = employeeLoan;
	}
	public int getEmployeeExp() {
		return employeeExp;
	}
	public void setEmployeeExp(int employeeExp) {
		this.employeeExp = employeeExp;

}
	public String getEmployeeLoc() {
		return employeeLoc;
	}
	public void setEmployeeLoc(String employeeLoc) {
		this.employeeLoc = employeeLoc;
	}
}
